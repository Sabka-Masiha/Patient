package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CustomerDTO;
import com.capstore.admin.repository.CustomerRepository;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@RestController
@RequestMapping("api/v1/")
@CrossOrigin(origins="http://localhost:4200",allowedHeaders="*")
public class CustomerController {
	
	@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping(value = "users", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<CustomerDTO> list() {
		return customerRepository.findAll();
	}

	@RequestMapping(value = "adminPage/addCustomer", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerDTO create(@RequestBody CustomerDTO customerDTO) {
		return customerRepository.saveAndFlush(customerDTO);
	}

	@RequestMapping(value = "adminPage/findCustomerById/{id}", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerDTO get(@PathVariable Integer id) {
		return customerRepository.findOne(id);
	}

	@RequestMapping(value = "adminPage/UpdateCustomerById/{id}", method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerDTO update(@PathVariable Integer id, @RequestBody CustomerDTO customerDTO) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		BeanUtils.copyProperties(customerDTO, existingCustomer);
		return customerRepository.saveAndFlush(existingCustomer);
	}

	@RequestMapping(value = "adminPage/DeleteCustomerById/{id}", method = RequestMethod.DELETE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public CustomerDTO delete(@PathVariable Integer id) {
		CustomerDTO existingCustomer = customerRepository.findOne(id);
		customerRepository.delete(existingCustomer);
		return existingCustomer;
	}

}
