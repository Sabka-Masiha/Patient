package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CustomerDTO;
import com.capstore.admin.model.ReturnRequestDTO;
import com.capstore.admin.model.ReturnRequestKey;
import com.capstore.admin.repository.ReturnRequestRepository;


@RestController
@RequestMapping("api/v1/")
public class ReturnRequestController 
{
	@Autowired
	private ReturnRequestRepository returnRequestRepository;

	@RequestMapping(value = "adminPage/returnAll", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<ReturnRequestDTO> list() {
		;
		return returnRequestRepository.findAll();
	}
	@RequestMapping(value = "adminPage/returnUpdateById/{id}", method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ReturnRequestDTO update(@PathVariable ReturnRequestKey id, @RequestBody ReturnRequestDTO returnRequestDTO) {
		ReturnRequestDTO existingRequest = returnRequestRepository.findOne(id);
		BeanUtils.copyProperties(returnRequestDTO, existingRequest);
		return returnRequestRepository.saveAndFlush(existingRequest);
	}


}
