package com.capstore.admin.model;

import java.io.Serializable;

import javax.persistence.Column;

public class ReturnRequestKey implements Serializable 
{

	
	@Column(name="returnstatus") 
	private String returnstatus;
	@Column(name="refundamount") 
	private int refundamount;
	/*@Column(name="orderid") 
	private int order;*/
	public String getReturnstatus() {
		return returnstatus;
	}
	public void setReturnstatus(String returnstatus) {
		this.returnstatus = returnstatus;
	}
	public int getRefundamount() {
		return refundamount;
	}
	public void setRefundamount(int refundamount) {
		this.refundamount = refundamount;
	}
	
	
	}